Configuration NodeJS
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $RequiredVersion,

        [Parameter(Mandatory = $true)]
        [ValidateSet("Chocolatey", "NuGet")]
        [string] $PackageProvider
    )

    Import-DscResource -ModuleName DscSingularResources

    OneGetPackage NodeJS
    {
        Name = "nodejs.install"
        RequiredVersion = $RequiredVersion
        ProviderName = $PackageProvider
    }
}