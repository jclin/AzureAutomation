﻿Copy-Item .\DscSingularResources -Destination 'C:\Program Files\WindowsPowerShell\Modules' -Recurse -Force -Verbose
Copy-Item .\DscCompositeResources -Destination 'C:\Program Files\WindowsPowerShell\Modules' -Recurse -Force -Verbose

if (Test-Path -Path .\VirtualMachineDependencies)
{
    Write-Host "Deleting MOF directory..."
    Remove-Item .\VirtualMachineDependencies -Recurse -Force
}

Write-Host "Compiling VirtualMachineDependencies.ps1"
. .\VirtualMachineDependencies.ps1
VirtualMachineDependencies -ComputerName "Win10-VM" -ConfigurationData .\VirtualMachineDependencies.ConfigData.psd1

Start-DscConfiguration -Wait -Verbose -Force -Path .\VirtualMachineDependencies