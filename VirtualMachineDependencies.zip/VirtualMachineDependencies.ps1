Configuration VirtualMachineDependencies
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $ComputerName
    )

    Import-DscResource -ModuleName DscCompositeResources
    Import-DscResource -ModuleName DscSingularResources

    Node $ComputerName
    {
        OneGetPackageSource Nuget
        {
            PackageSourceName = $ConfigurationData.NugetRepoConfig.RepoName
            Url =  $ConfigurationData.NugetRepoConfig.RepoUrl
            ProviderName = $ConfigurationData.NugetRepoConfig.Name
        }

        OneGetPackageSource Chocolatey
        {
            PackageSourceName = $ConfigurationData.ChocolateyRepoConfig.RepoName
            Url =  $ConfigurationData.ChocolateyRepoConfig.RepoUrl
            ProviderName = $ConfigurationData.ChocolateyRepoConfig.Name
        }

        NUnit NUnit
        {
            DependsOn = "[OneGetPackageSource]Nuget"
            RequiredVersion = $ConfigurationData.NUnitVersion
            PackageProvider = $ConfigurationData.NugetRepoConfig.Name
        }

        NodeJS Node
        {
            DependsOn = "[OneGetPackageSource]Chocolatey"
            RequiredVersion = $ConfigurationData.NodeJSVersion
            PackageProvider = $ConfigurationData.ChocolateyRepoConfig.Name
        }
    }
}