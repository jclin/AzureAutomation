Configuration NUnit
{
    param
    (
        [Parameter(Mandatory = $true)]
        [string] $RequiredVersion,

        [Parameter(Mandatory = $true)]
        [ValidateSet("Chocolatey", "NuGet")]
        [string] $PackageProvider
    )

    Import-DscResource -ModuleName DscSingularResources

    OneGetPackage NUnit
    {
        Name = "NUnit"
        RequiredVersion = "$RequiredVersion"
        ProviderName = $PackageProvider
    }

    OneGetPackage NUnit.Runners
    {
        DependsOn = "[OneGetPackage]NUnit"
        Name = "NUnit.Runners"
        RequiredVersion = "$RequiredVersion"
        ProviderName = $PackageProvider
    }

    OneGetPackageToPath NUnit.RunnersPath
    {
        DependsOn = "[OneGetPackage]NUnit.Runners"
        PackageName = "NUnit.Runners"
        Version = "$RequiredVersion"
        SubFolder = "tools"
    }

    WindowsOptionalFeature DotNetThreeFive
    {
        Name = "NetFx3"
        Ensure = "Enable"
        NoWindowsUpdateCheck = $false
    }
}